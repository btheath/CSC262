﻿namespace FinanceTracker.Forms
{
    partial class TransactionForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblFormTitle = new Label();
            pnlValidation = new Panel();
            lblValidationMsg = new Label();
            lblCategory = new Label();
            cboCategory = new ComboBox();
            lblType = new Label();
            cboType = new ComboBox();
            lblAmount = new Label();
            txtAmount = new TextBox();
            lblDate = new Label();
            dtpDate = new DateTimePicker();
            lblDescription = new Label();
            txtDescription = new TextBox();
            lblRequiredNote = new Label();
            lblCategoryHint = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            pnlValidation.SuspendLayout();
            SuspendLayout();
            // 
            // lblFormTitle
            // 
            lblFormTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblFormTitle.ForeColor = Color.FromArgb(44, 62, 80);
            lblFormTitle.Location = new Point(12, 15);
            lblFormTitle.Name = "lblFormTitle";
            lblFormTitle.Size = new Size(406, 32);
            lblFormTitle.TabIndex = 0;
            lblFormTitle.Text = "➕ Add New Transaction";
            // 
            // pnlValidation
            // 
            pnlValidation.BackColor = Color.IndianRed;
            pnlValidation.Controls.Add(lblValidationMsg);
            pnlValidation.Location = new Point(12, 55);
            pnlValidation.Name = "pnlValidation";
            pnlValidation.Size = new Size(406, 30);
            pnlValidation.TabIndex = 1;
            pnlValidation.Visible = false;
            // 
            // lblValidationMsg
            // 
            lblValidationMsg.Dock = DockStyle.Fill;
            lblValidationMsg.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblValidationMsg.ForeColor = Color.White;
            lblValidationMsg.Location = new Point(0, 0);
            lblValidationMsg.Name = "lblValidationMsg";
            lblValidationMsg.Padding = new Padding(6, 0, 0, 0);
            lblValidationMsg.Size = new Size(406, 30);
            lblValidationMsg.TabIndex = 0;
            lblValidationMsg.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblCategory
            // 
            lblCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblCategory.Location = new Point(12, 97);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(190, 18);
            lblCategory.TabIndex = 2;
            lblCategory.Text = "Category *";
            // 
            // cboCategory
            // 
            cboCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCategory.Font = new Font("Segoe UI", 9F);
            cboCategory.Location = new Point(12, 117);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(190, 23);
            cboCategory.TabIndex = 3;
            cboCategory.SelectedIndexChanged += cboCategory_SelectedIndexChanged;
            // 
            // lblType
            // 
            lblType.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblType.Location = new Point(220, 97);
            lblType.Name = "lblType";
            lblType.Size = new Size(198, 18);
            lblType.TabIndex = 4;
            lblType.Text = "Type *";
            // 
            // cboType
            // 
            cboType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboType.Font = new Font("Segoe UI", 9F);
            cboType.Location = new Point(220, 117);
            cboType.Name = "cboType";
            cboType.Size = new Size(198, 23);
            cboType.TabIndex = 5;
            // 
            // lblAmount
            // 
            lblAmount.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblAmount.Location = new Point(12, 157);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(190, 18);
            lblAmount.TabIndex = 6;
            lblAmount.Text = "Amount ($) *";
            // 
            // txtAmount
            // 
            txtAmount.Font = new Font("Segoe UI", 9F);
            txtAmount.Location = new Point(12, 177);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(190, 23);
            txtAmount.TabIndex = 7;
            txtAmount.KeyPress += txtAmount_KeyPress;
            // 
            // lblDate
            // 
            lblDate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblDate.Location = new Point(220, 157);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(198, 18);
            lblDate.TabIndex = 8;
            lblDate.Text = "Date *";
            // 
            // dtpDate
            // 
            dtpDate.Font = new Font("Segoe UI", 9F);
            dtpDate.Format = DateTimePickerFormat.Short;
            dtpDate.Location = new Point(220, 177);
            dtpDate.Name = "dtpDate";
            dtpDate.Size = new Size(198, 23);
            dtpDate.TabIndex = 9;
            // 
            // lblDescription
            // 
            lblDescription.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblDescription.Location = new Point(12, 217);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(406, 18);
            lblDescription.TabIndex = 10;
            lblDescription.Text = "Description (optional)";
            // 
            // txtDescription
            // 
            txtDescription.Font = new Font("Segoe UI", 9F);
            txtDescription.Location = new Point(12, 237);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.ScrollBars = ScrollBars.Vertical;
            txtDescription.Size = new Size(406, 70);
            txtDescription.TabIndex = 11;
            // 
            // lblRequiredNote
            // 
            lblRequiredNote.Font = new Font("Segoe UI", 8F);
            lblRequiredNote.ForeColor = Color.Gray;
            lblRequiredNote.Location = new Point(12, 338);
            lblRequiredNote.Name = "lblRequiredNote";
            lblRequiredNote.Size = new Size(200, 18);
            lblRequiredNote.TabIndex = 13;
            lblRequiredNote.Text = "* Required fields";
            // 
            // lblCategoryHint
            // 
            lblCategoryHint.Font = new Font("Segoe UI", 8F);
            lblCategoryHint.ForeColor = Color.Gray;
            lblCategoryHint.Location = new Point(12, 315);
            lblCategoryHint.Name = "lblCategoryHint";
            lblCategoryHint.Size = new Size(406, 18);
            lblCategoryHint.TabIndex = 12;
            lblCategoryHint.Text = "Can't find your category? Open Manage Categories from the Dashboard first.";
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.FromArgb(39, 174, 96);
            btnSave.Cursor = Cursors.Hand;
            btnSave.FlatAppearance.BorderSize = 0;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(12, 368);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(190, 38);
            btnSave.TabIndex = 14;
            btnSave.Text = "Save Transaction";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(127, 140, 141);
            btnCancel.Cursor = Cursors.Hand;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI", 10F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(220, 368);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(198, 38);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // TransactionForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(430, 425);
            Controls.Add(lblFormTitle);
            Controls.Add(pnlValidation);
            Controls.Add(lblCategory);
            Controls.Add(cboCategory);
            Controls.Add(lblType);
            Controls.Add(cboType);
            Controls.Add(lblAmount);
            Controls.Add(txtAmount);
            Controls.Add(lblDate);
            Controls.Add(dtpDate);
            Controls.Add(lblDescription);
            Controls.Add(txtDescription);
            Controls.Add(lblCategoryHint);
            Controls.Add(lblRequiredNote);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Font = new Font("Segoe UI", 9F);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "TransactionForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Add Transaction";
            Load += TransactionForm_Load;
            pnlValidation.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblFormTitle;
        private System.Windows.Forms.Panel pnlValidation;
        private System.Windows.Forms.Label lblValidationMsg;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cboCategory;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.ComboBox cboType;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblCategoryHint;
        private System.Windows.Forms.Label lblRequiredNote;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}
