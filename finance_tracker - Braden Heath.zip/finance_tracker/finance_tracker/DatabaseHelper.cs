﻿using FinanceTracker.Classes;
using MySqlConnector;                  
using System;
using System.Collections.Generic;
using System.Transactions;
using Transaction = FinanceTracker.Classes.Transaction;

namespace FinanceTracker.Database
{

    // This static class encapsulates all database interactions.
    public static class DatabaseHelper
    {
        // connection string with parameters for connecting to the MariaDB database.
        private const string ConnectionString =
            "Server=localhost;" +
            "Port=3306;" +
            "Database=finance_tracker;" +
            "User=root;" +
            "Password=S3cret088;" +
            "Convert Zero Datetime=True;"; 

        // Opens and returns a new MySqlConnection.
        // Callers are responsible for disposing it (use 'using').        
        private static MySqlConnection GetOpenConnection()
        {
            var conn = new MySqlConnection(ConnectionString);
            conn.Open();   // throws MySqlException on failure
            return conn;
        }

       
        // Returns all rows from the categories table as Category objects.
        // Called on startup and whenever the category list needs refreshing.
        
        public static List<Category> GetAllCategories()
        {
            var categories = new List<Category>();   // will hold multiple Category objects

            // 'using' ensures the connection is closed even if an exception occurs
            using (var conn = GetOpenConnection())
            {
                // Pull all columns needed to populate the Category objects. Ordering by name is convenient for display.
                string sql = "SELECT category_id, category_name, category_type, " +
                             "monthly_budget_limit, hex_color " +
                             "FROM categories ORDER BY category_name;";
                // Execute the query and read the results
                using (var cmd = new MySqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Build a new Category object for each database row
                        var cat = new Category
                        {
                            // Map each column to the corresponding property in the Category class
                            CategoryId = reader.GetInt32("category_id"),
                            CategoryName = reader.GetString("category_name"),
                            CategoryType = reader.GetString("category_type"),
                            MonthlyBudgetLimit = reader.GetDecimal("monthly_budget_limit"),
                            HexColor = reader.GetString("hex_color")
                        };
                        categories.Add(cat);
                    }
                }
            }
            // returns an empty list (not null) if the table is empty
            return categories;   
        }

        // Inserts a new category row and returns the generated CategoryId.
        public static int InsertCategory(Category cat)
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "INSERT INTO categories " +
                             "(category_name, category_type, monthly_budget_limit, hex_color) " +
                             "VALUES (@name, @type, @limit, @color);";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    // Parameterised queries prevent SQL injection
                    cmd.Parameters.AddWithValue("@name", cat.CategoryName);
                    cmd.Parameters.AddWithValue("@type", cat.CategoryType);
                    cmd.Parameters.AddWithValue("@limit", cat.MonthlyBudgetLimit);
                    cmd.Parameters.AddWithValue("@color", cat.HexColor);
                    cmd.ExecuteNonQuery();

                    // LastInsertedId is a property of MySqlCommand that gives the auto-incremented ID of the last inserted row
                    return (int)cmd.LastInsertedId;
                }
            }
        }

        // Updates an existing category row based on the CategoryId.
        public static void UpdateCategory(Category cat)
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "UPDATE categories SET " +
                             "category_name = @name, " +
                             "category_type = @type, " +
                             "monthly_budget_limit = @limit, " +
                             "hex_color = @color " +
                             "WHERE category_id = @id;";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@name", cat.CategoryName);
                    cmd.Parameters.AddWithValue("@type", cat.CategoryType);
                    cmd.Parameters.AddWithValue("@limit", cat.MonthlyBudgetLimit);
                    cmd.Parameters.AddWithValue("@color", cat.HexColor);
                    cmd.Parameters.AddWithValue("@id", cat.CategoryId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Deletes a single category by its primary key. Transactions linked to this
        public static void DeleteCategory(int categoryId)
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "DELETE FROM categories WHERE category_id = @id;";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", categoryId);
                    cmd.ExecuteNonQuery();
                }
            }
        }



        // Returns transactions filtered by an optional date range.
        public static List<Transaction> GetTransactions(
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            // The date filters are optional. If startDate is null, there is no lower bound on the transaction_date.
            var transactions = new List<Transaction>();

            using (var conn = GetOpenConnection())
            {
                // Join to pull in the human-readable category name
                string sql = "SELECT t.transaction_id, t.category_id, c.category_name, " +
                             "t.amount, t.transaction_type, t.description, " +
                             "t.transaction_date, t.created_at " +
                             "FROM transactions t " +
                             "JOIN categories c ON t.category_id = c.category_id " +
                             "WHERE (@start IS NULL OR t.transaction_date >= @start) " +
                             "AND   (@end   IS NULL OR t.transaction_date <= @end) " +
                             "ORDER BY t.transaction_date DESC, t.created_at DESC;";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    // DBNull is used when the filter is not applied
                    cmd.Parameters.AddWithValue("@start",
                        startDate.HasValue ? (object)startDate.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@end",
                        endDate.HasValue ? (object)endDate.Value : DBNull.Value);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Map each row to a Transaction object, including the category name from the joined table
                            transactions.Add(new Transaction
                            {
                                TransactionId = reader.GetInt32("transaction_id"),
                                CategoryId = reader.GetInt32("category_id"),
                                CategoryName = reader.GetString("category_name"),
                                Amount = reader.GetDecimal("amount"),
                                TransactionType = reader.GetString("transaction_type"),
                                Description = reader.GetString("description"),
                                TransactionDate = reader.GetDateTime("transaction_date"),
                                CreatedAt = reader.GetDateTime("created_at")
                            });
                        }
                    }
                }
            }
            // returns an empty list (not null) if no transactions match the filters
            return transactions;
        }

        // Inserts a new transaction row and returns the generated TransactionId.
        public static int InsertTransaction(Transaction txn)
        {
            using (var conn = GetOpenConnection())
            {
                // The transaction_date is stored as DATE in the database, so we take only the date part of the DateTime.
                string sql = "INSERT INTO transactions " +
                             "(category_id, amount, transaction_type, description, transaction_date) " +
                             "VALUES (@catId, @amount, @type, @desc, @date);";
                
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@catId", txn.CategoryId);
                    cmd.Parameters.AddWithValue("@amount", txn.Amount);
                    cmd.Parameters.AddWithValue("@type", txn.TransactionType);
                    cmd.Parameters.AddWithValue("@desc", txn.Description);
                    cmd.Parameters.AddWithValue("@date", txn.TransactionDate.Date);  
                    cmd.ExecuteNonQuery();

                    return (int)cmd.LastInsertedId;
                }
            }
        }

        // Updates an existing transaction row based on the TransactionId.
        public static void UpdateTransaction(Transaction txn)
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "UPDATE transactions SET " +
                             "category_id = @catId, " +
                             "amount = @amount, " +
                             "transaction_type = @type, " +
                             "description = @desc, " +
                             "transaction_date = @date " +
                             "WHERE transaction_id = @id;";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@catId", txn.CategoryId);
                    cmd.Parameters.AddWithValue("@amount", txn.Amount);
                    cmd.Parameters.AddWithValue("@type", txn.TransactionType);
                    cmd.Parameters.AddWithValue("@desc", txn.Description);
                    cmd.Parameters.AddWithValue("@date", txn.TransactionDate.Date);
                    cmd.Parameters.AddWithValue("@id", txn.TransactionId);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        // Deletes a single transaction by its primary key.
        public static void DeleteTransaction(int transactionId)
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "DELETE FROM transactions WHERE transaction_id = @id;";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", transactionId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Returns a dictionary mapping category names to lists of monthly spending totals
        // for the past N months (default 6). Only includes "Expense" transactions.
        // ML predictor uses this data to forecast next month's spending per category.
        public static Dictionary<string, List<decimal>> GetMonthlyCategoryTotals(
            int lookbackMonths = 6)
        {
            var result = new Dictionary<string, List<decimal>>();

            // Build a list of (year, month) pairs for the lookback window
            var months = new List<(int year, int month)>();
            DateTime cursor = DateTime.Today;

            for (int i = lookbackMonths - 1; i >= 0; i--)
            {
                // Go back i months from today
                DateTime m = cursor.AddMonths(-i);
                months.Add((m.Year, m.Month));
            }
            // The SQL query aggregates expenses by category and month, filtering to the lookback window.
            using (var conn = GetOpenConnection())
            {
                string sql = "SELECT c.category_name, " +
                             "YEAR(t.transaction_date)  AS yr, " +
                             "MONTH(t.transaction_date) AS mo, " +
                             "SUM(t.amount)             AS total " +
                             "FROM transactions t " +
                             "JOIN categories c ON t.category_id = c.category_id " +
                             "WHERE t.transaction_type = 'Expense' " +
                             "AND t.transaction_date >= DATE_SUB(CURDATE(), INTERVAL @months MONTH) " +
                             "GROUP BY c.category_name, yr, mo " +
                             "ORDER BY c.category_name, yr, mo;";
                
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    // The lookbackMonths parameter is passed to the query to dynamically adjust the date filter.
                    cmd.Parameters.AddWithValue("@months", lookbackMonths);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string catName = reader.GetString("category_name");
                            int year = reader.GetInt32("yr");
                            int month = reader.GetInt32("mo");
                            decimal total = reader.GetDecimal("total");

                            // Initialise list for categories we haven't seen before
                            if (!result.ContainsKey(catName))
                                result[catName] = new List<decimal>();

                            result[catName].Add(total);
                        }
                    }
                }
            }

            // For categories that have no data in some months, the list is shorter.
            // The predictor handles variable-length lists, so no padding is needed here.
            return result;
        }

        // Returns the net balance for the current calendar month:
        // total income minus total expenses. If there are no transactions, returns 0.
        public static decimal GetCurrentMonthBalance()
        {
            using (var conn = GetOpenConnection())
            {
                string sql = "SELECT " +
                             "IFNULL(SUM(CASE WHEN transaction_type = 'Income'  THEN amount ELSE 0 END), 0) " +
                             "- IFNULL(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) " +
                             "AS net_balance " +
                             "FROM transactions " +
                             "WHERE YEAR(transaction_date)  = YEAR(CURDATE()) " +
                             "AND   MONTH(transaction_date) = MONTH(CURDATE());";

                using (var cmd = new MySqlCommand(sql, conn))
                {
                    object rawResult = cmd.ExecuteScalar();

                    // ExecuteScalar returns DBNull if no rows exist
                    return rawResult == DBNull.Value ? 0m : Convert.ToDecimal(rawResult);
                }
            }
        }
    }
}
