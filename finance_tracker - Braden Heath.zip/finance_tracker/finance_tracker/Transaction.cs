﻿using System;

namespace FinanceTracker.Classes
{
    
    // Encapsulates a financial transaction record. Maps directly to the `transactions` table in MariaDB.    
    public class Transaction
    {        
        // Auto-incremented primary key from the database. A value of 0 means the object has not yet been saved.        
        public int TransactionId { get; set; }

        
        // Foreign key linking to a Category object.        
        public int CategoryId { get; set; }

        
        // Human-readable name of the category (populated via JOIN).             
        public string CategoryName { get; set; }

        
        // Positive decimal amount in USD. Whether it is income or expense is determined by TransactionType.        
        public decimal Amount { get; set; }      
        
        // "Income" or "Expense" — controls how the amount affects the balance.        
        public string TransactionType { get; set; }

        // Optional free-text note the user enters to describe the transaction.        
        public string Description { get; set; }
        
        // The date the transaction occurred (not necessarily today).        
        public DateTime TransactionDate { get; set; }
        
        // Timestamp set by the database when the row is inserted.        
        public DateTime CreatedAt { get; set; }        

        
        // Default constructor — sets defaults so the object is
        // always in a valid state even before the user fills in a form.        
        public Transaction()
        {
            TransactionId = 0;               
            CategoryId = 0;
            CategoryName = string.Empty;
            Amount = 0.00m;
            TransactionType = "Expense";       
            Description = string.Empty;
            // default to today
            TransactionDate = DateTime.Today;  
            CreatedAt = DateTime.Now;
        }         
               
        
    }
}
