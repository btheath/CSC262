using FinanceTracker.Classes;
using FinanceTracker.Database;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Transactions;
using System.Windows.Forms;
using Transaction = FinanceTracker.Classes.Transaction;

namespace FinanceTracker.Forms
{
    public partial class MainForm : Form
    {
        // SpendingPredictor is instantiated here so it can be reused every time the user clicks "ML Predictions"
        // without re-allocating a new object each time.
        private readonly SpendingPredictor _spendingPredictor;

        // Stores the last-loaded transactions so we can reference them if needed without a second DB call.
        private List<Transaction> _recentTransactions;

        public MainForm()
        {
            InitializeComponent();

            // Create one SpendingPredictor instance for the lifetime of this form
            _spendingPredictor = new SpendingPredictor();
            _recentTransactions = new List<Transaction>();
        }


        private void MainForm_Load(object sender, EventArgs e)
        {

            this.Text = "Finance Tracker – Dashboard";

            // Configure the DataGridView appearance once at load time
            ConfigureTransactionGrid();

            // Populate the dashboard with live data from the DB
            RefreshDashboard();
        }
        // Sets up the DataGridView with specific columns and styles for displaying transactions.
        private void ConfigureTransactionGrid()
        {
            // we define columns manually
            dgvRecentTxns.AutoGenerateColumns = false;
            // no blank row at bottom
            dgvRecentTxns.AllowUserToAddRows = false;
            dgvRecentTxns.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRecentTxns.RowHeadersVisible = false;
            dgvRecentTxns.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 248, 252);

            // Clear any auto-generated columns from a previous load
            dgvRecentTxns.Columns.Clear();

            // Define each column explicitly so we control header text and width
            dgvRecentTxns.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colDate",
                HeaderText = "Date",
                DataPropertyName = "TransactionDate",
                Width = 95,
                DefaultCellStyle = { Format = "yyyy-MM-dd" }
            });
            // Category name is pulled via a JOIN in the DB query and mapped to the Transaction model's CategoryName property
            dgvRecentTxns.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colCategory",
                HeaderText = "Category",
                DataPropertyName = "CategoryName",
                Width = 120
            });
            // Type is either "Income" or "Expense", also mapped in the DB query
            dgvRecentTxns.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colType",
                HeaderText = "Type",
                DataPropertyName = "TransactionType",
                Width = 75
            });
            // Amount is formatted as currency with 2 decimal places and right-aligned for easy scanning
            dgvRecentTxns.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colAmount",
                HeaderText = "Amount ($)",
                DataPropertyName = "Amount",
                Width = 90,
                DefaultCellStyle = { Format = "F2", Alignment = DataGridViewContentAlignment.MiddleRight }
            });
            // Description is free-form text, so we allow it to fill the remaining space and wrap if needed
            dgvRecentTxns.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colDescription",
                HeaderText = "Description",
                DataPropertyName = "Description",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });
        }

        // Reloads all dashboard data from the database.
        private void RefreshDashboard()
        {
            try
            {

                // Get the current month's balance from the DB and display it
                decimal monthBalance = DatabaseHelper.GetCurrentMonthBalance();
                lblBalance.Text = $"${monthBalance:F2}";

                // Color the balance green if positive, red if negative
                lblBalance.ForeColor = monthBalance >= 0
                    ? Color.FromArgb(39, 174, 96)
                    : Color.FromArgb(192, 57, 43);


                // Retrieve the 50 most-recent transactions (no date filter)
                _recentTransactions = DatabaseHelper.GetTransactions();

                // DataSource binding keeps the grid in sync with the list
                dgvRecentTxns.DataSource = null;          // clear first to force refresh
                dgvRecentTxns.DataSource = _recentTransactions;

                // Color expense rows red-tinted, income rows green-tinted
                ColorTransactionRows();

                // Update the status bar with how many transactions were loaded and when
                toolStripStatusLabel1.Text =
                    $"Loaded {_recentTransactions.Count} transactions  |  " +
                    $"Last refreshed: {DateTime.Now:HH:mm:ss}";
            }
            catch (Exception ex)
            {
                // Show a user-friendly message instead of crashing
                MessageBox.Show(
                    $"Could not load dashboard data.\n\nError: {ex.Message}\n\n" +
                    "Please check your database connection settings in DatabaseHelper.cs.",
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // applied red/green tint to transaction rows based on type for quick visual scanning
        private void ColorTransactionRows()
        {
            foreach (DataGridViewRow row in dgvRecentTxns.Rows)
            {
                if (row.DataBoundItem is Transaction txn)
                {
                    row.DefaultCellStyle.BackColor = txn.TransactionType == "Income"
                        ? Color.FromArgb(230, 255, 237)
                        : Color.FromArgb(255, 235, 235);
                }
            }
        }




        // Loads historical spending data from the DB, runs the SpendingPredictor, and populates the predictions list box.               
        private void LoadMlPredictions()
        {
            try
            {
                // Clear out any predictions from a previous run
                _spendingPredictor.ClearHistory();
                lstPredictions.Items.Clear();

                // Pull the last 6 months of spending per category from the DB
                Dictionary<string, List<decimal>> history =
                    DatabaseHelper.GetMonthlyCategoryTotals(lookbackMonths: 6);

                // Feed each category's history into the predictor
                foreach (var kvp in history)
                    _spendingPredictor.LoadHistory(kvp.Key, kvp.Value);

                // Run the linear regression and get results
                List<PredictionResult> predictions = _spendingPredictor.PredictNextMonth();

                if (predictions.Count == 0)
                {
                    lstPredictions.Items.Add("Not enough data yet. " +
                        "Add at least 2 months of transactions to see predictions.");
                    return;
                }

                // Format each result as a readable string for the list box
                foreach (PredictionResult pr in predictions)
                {
                    // Unicode arrows make the trend immediately scannable
                    string trendIcon = pr.Trend switch
                    {
                        "Increasing" => "↑",
                        "Decreasing" => "↓",
                        _ => "→"
                    };

                    lstPredictions.Items.Add(
                        $"{trendIcon} {pr.CategoryName,-18} " +
                        $"${pr.PredictedAmount,8:F2}   " +
                        $"(confidence: {pr.ConfidencePercent:F0}%)");
                }
            }
            catch (Exception ex)
            {
                lstPredictions.Items.Add($"Prediction error: {ex.Message}");
            }
        }

        // Opens the TransactionForm to add a new transaction. After the form is closed, the dashboard is refreshed to show the new data.
        private void btnAddTransaction_Click(object sender, EventArgs e)
        {
            using (var txnForm = new TransactionForm())
            {
                // ShowDialog blocks until the user closes the child form
                txnForm.ShowDialog(this);
            }

            // Always refresh 
            RefreshDashboard();
        }


        // Opens the CategoryManagerForm.
        private void btnManageCategories_Click(object sender, EventArgs e)
        {
            using (var catForm = new CategoryManagerForm())
            {
                catForm.ShowDialog(this);
            }
            RefreshDashboard();
        }

        // Manual refresh button — reloads data from the DB.        
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshDashboard();
        }


        // Runs the ML predictor and shows results in the list box.        
        private void btnPredictions_Click(object sender, EventArgs e)
        {
            LoadMlPredictions();
        }

        private void btnDeleteTransaction_Click(object sender, EventArgs e)
        {
            {
                // Make sure something is selected
                if (dgvRecentTxns.CurrentRow?.DataBoundItem is not Transaction selectedTxn)
                {
                    MessageBox.Show("Please select a transaction to delete.");
                    return;
                }

                // Confirm delete
                var confirm = MessageBox.Show(
                    $"Delete transaction '{selectedTxn.Description}'?",
                    "Confirm",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm != DialogResult.Yes) return;

                try
                {
                    DatabaseHelper.DeleteTransaction(selectedTxn.TransactionId);

                    MessageBox.Show("Transaction deleted.");

                    RefreshDashboard();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting transaction: {ex.Message}");
                }
            }



        }
        

        
    }
}
