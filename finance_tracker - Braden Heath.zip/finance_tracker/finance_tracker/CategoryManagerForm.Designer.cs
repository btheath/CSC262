﻿namespace FinanceTracker.Forms
{
    partial class CategoryManagerForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgvCategories;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblStatus;

        private System.Windows.Forms.Panel pnlEdit;
        private System.Windows.Forms.TextBox txtEditName;
        private System.Windows.Forms.ComboBox cboEditType;
        private System.Windows.Forms.TextBox txtEditBudget;
        private System.Windows.Forms.TextBox txtEditColor;
        private System.Windows.Forms.Panel pnlColorPreview;
        private System.Windows.Forms.Button btnPickColor;
        private System.Windows.Forms.Button btnSaveEdit;
        private System.Windows.Forms.Button btnCancelEdit;

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblBudget;
        private System.Windows.Forms.Label lblColor;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvCategories = new System.Windows.Forms.DataGridView();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();

            this.pnlEdit = new System.Windows.Forms.Panel();
            this.txtEditName = new System.Windows.Forms.TextBox();
            this.cboEditType = new System.Windows.Forms.ComboBox();
            this.txtEditBudget = new System.Windows.Forms.TextBox();
            this.txtEditColor = new System.Windows.Forms.TextBox();
            this.pnlColorPreview = new System.Windows.Forms.Panel();
            this.btnPickColor = new System.Windows.Forms.Button();
            this.btnSaveEdit = new System.Windows.Forms.Button();
            this.btnCancelEdit = new System.Windows.Forms.Button();

            this.lblName = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblBudget = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).BeginInit();
            this.pnlEdit.SuspendLayout();
            this.SuspendLayout();

            // dgvCategories
            this.dgvCategories.Location = new System.Drawing.Point(12, 12);
            this.dgvCategories.Size = new System.Drawing.Size(560, 250);
            this.dgvCategories.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCategories_CellDoubleClick);

            // btnAddNew
            this.btnAddNew.Location = new System.Drawing.Point(12, 270);
            this.btnAddNew.Size = new System.Drawing.Size(100, 30);
            this.btnAddNew.Text = "Add New";
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);

            // btnDelete
            this.btnDelete.Location = new System.Drawing.Point(120, 270);
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            // lblStatus
            this.lblStatus.Location = new System.Drawing.Point(12, 310);
            this.lblStatus.Size = new System.Drawing.Size(560, 25);
            this.lblStatus.Text = "Ready.";

            // pnlEdit
            this.pnlEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEdit.Location = new System.Drawing.Point(12, 340);
            this.pnlEdit.Size = new System.Drawing.Size(560, 200);

            // Labels
            this.lblName.Text = "Name:";
            this.lblName.Location = new System.Drawing.Point(10, 15);

            this.lblType.Text = "Type:";
            this.lblType.Location = new System.Drawing.Point(10, 50);

            this.lblBudget.Text = "Budget:";
            this.lblBudget.Location = new System.Drawing.Point(10, 85);

            this.lblColor.Text = "Color:";
            this.lblColor.Location = new System.Drawing.Point(10, 120);

            // txtEditName
            this.txtEditName.Location = new System.Drawing.Point(120, 12);
            this.txtEditName.Size = new System.Drawing.Size(200, 23);

            // cboEditType
            this.cboEditType.Location = new System.Drawing.Point(120, 47);
            this.cboEditType.Size = new System.Drawing.Size(200, 23);
            this.cboEditType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // txtEditBudget
            this.txtEditBudget.Location = new System.Drawing.Point(120, 82);
            this.txtEditBudget.Size = new System.Drawing.Size(200, 23);

            // txtEditColor
            this.txtEditColor.Location = new System.Drawing.Point(120, 117);
            this.txtEditColor.Size = new System.Drawing.Size(100, 23);
            this.txtEditColor.TextChanged += new System.EventHandler(this.txtEditColor_TextChanged);

            // pnlColorPreview
            this.pnlColorPreview.Location = new System.Drawing.Point(230, 117);
            this.pnlColorPreview.Size = new System.Drawing.Size(40, 23);
            this.pnlColorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // btnPickColor
            this.btnPickColor.Location = new System.Drawing.Point(280, 115);
            this.btnPickColor.Size = new System.Drawing.Size(75, 25);
            this.btnPickColor.Text = "Pick";
            this.btnPickColor.Click += new System.EventHandler(this.btnPickColor_Click);

            // btnSaveEdit
            this.btnSaveEdit.Location = new System.Drawing.Point(120, 160);
            this.btnSaveEdit.Size = new System.Drawing.Size(100, 30);
            this.btnSaveEdit.Text = "Save";
            this.btnSaveEdit.Click += new System.EventHandler(this.btnSaveEdit_Click);

            // btnCancelEdit
            this.btnCancelEdit.Location = new System.Drawing.Point(230, 160);
            this.btnCancelEdit.Size = new System.Drawing.Size(100, 30);
            this.btnCancelEdit.Text = "Cancel";
            this.btnCancelEdit.Click += new System.EventHandler(this.btnCancelEdit_Click);

            // Add controls to panel
            this.pnlEdit.Controls.Add(this.lblName);
            this.pnlEdit.Controls.Add(this.lblType);
            this.pnlEdit.Controls.Add(this.lblBudget);
            this.pnlEdit.Controls.Add(this.lblColor);

            this.pnlEdit.Controls.Add(this.txtEditName);
            this.pnlEdit.Controls.Add(this.cboEditType);
            this.pnlEdit.Controls.Add(this.txtEditBudget);
            this.pnlEdit.Controls.Add(this.txtEditColor);
            this.pnlEdit.Controls.Add(this.pnlColorPreview);
            this.pnlEdit.Controls.Add(this.btnPickColor);
            this.pnlEdit.Controls.Add(this.btnSaveEdit);
            this.pnlEdit.Controls.Add(this.btnCancelEdit);

            // Form
            this.ClientSize = new System.Drawing.Size(600, 560);
            this.Controls.Add(this.dgvCategories);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pnlEdit);

            this.Load += new System.EventHandler(this.CategoryManagerForm_Load);

            this.Text = "Category Manager";

            ((System.ComponentModel.ISupportInitialize)(this.dgvCategories)).EndInit();
            this.pnlEdit.ResumeLayout(false);
            this.pnlEdit.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}