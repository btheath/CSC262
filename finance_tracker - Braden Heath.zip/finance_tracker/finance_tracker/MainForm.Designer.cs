﻿namespace FinanceTracker.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            lblTitle = new Label();
            lblBalanceCaption = new Label();
            lblBalance = new Label();
            lblBalanceHint = new Label();
            dgvRecentTxns = new DataGridView();
            btnAddTransaction = new Button();
            btnManageCategories = new Button();
            btnRefresh = new Button();
            btnPredictions = new Button();
            lblPredictionsTitle = new Label();
            lstPredictions = new ListBox();
            lblPredictionsHint = new Label();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            pnlLeft = new Panel();
            pnlButtons = new Panel();
            btnDeleteTransaction = new Button();
            pnlRight = new Panel();
            pnlHeader = new Panel();
            ((System.ComponentModel.ISupportInitialize)dgvRecentTxns).BeginInit();
            statusStrip1.SuspendLayout();
            pnlLeft.SuspendLayout();
            pnlButtons.SuspendLayout();
            pnlRight.SuspendLayout();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.Dock = DockStyle.Fill;
            lblTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(0, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Padding = new Padding(10, 0, 0, 0);
            lblTitle.Size = new Size(1000, 60);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Finance Tracker Dashboard";
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblBalanceCaption
            // 
            lblBalanceCaption.Font = new Font("Segoe UI", 10F);
            lblBalanceCaption.ForeColor = Color.FromArgb(80, 80, 80);
            lblBalanceCaption.Location = new Point(10, 10);
            lblBalanceCaption.Name = "lblBalanceCaption";
            lblBalanceCaption.Size = new Size(580, 22);
            lblBalanceCaption.TabIndex = 4;
            lblBalanceCaption.Text = "This Month's Net Balance:";
            // 
            // lblBalance
            // 
            lblBalance.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblBalance.ForeColor = Color.FromArgb(39, 174, 96);
            lblBalance.Location = new Point(10, 32);
            lblBalance.Name = "lblBalance";
            lblBalance.Size = new Size(300, 48);
            lblBalance.TabIndex = 3;
            lblBalance.Text = "$0.00";
            // 
            // lblBalanceHint
            // 
            lblBalanceHint.Font = new Font("Segoe UI", 8F);
            lblBalanceHint.ForeColor = Color.Gray;
            lblBalanceHint.Location = new Point(10, 82);
            lblBalanceHint.Name = "lblBalanceHint";
            lblBalanceHint.Size = new Size(580, 18);
            lblBalanceHint.TabIndex = 2;
            lblBalanceHint.Text = "Green = surplus  |  Red = deficit  |  Income minus expenses for the current calendar month";
            // 
            // dgvRecentTxns
            // 
            dgvRecentTxns.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            dgvRecentTxns.BackgroundColor = Color.White;
            dgvRecentTxns.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(44, 62, 80);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = Color.White;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvRecentTxns.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvRecentTxns.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRecentTxns.EnableHeadersVisualStyles = false;
            dgvRecentTxns.Font = new Font("Segoe UI", 9F);
            dgvRecentTxns.Location = new Point(10, 153);
            dgvRecentTxns.Name = "dgvRecentTxns";
            dgvRecentTxns.RowTemplate.Height = 24;
            dgvRecentTxns.Size = new Size(580, 808);
            dgvRecentTxns.TabIndex = 0;
            // 
            // btnAddTransaction
            // 
            btnAddTransaction.BackColor = Color.FromArgb(39, 174, 96);
            btnAddTransaction.Cursor = Cursors.Hand;
            btnAddTransaction.FlatAppearance.BorderSize = 0;
            btnAddTransaction.FlatStyle = FlatStyle.Flat;
            btnAddTransaction.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnAddTransaction.ForeColor = Color.White;
            btnAddTransaction.Location = new Point(0, 0);
            btnAddTransaction.Name = "btnAddTransaction";
            btnAddTransaction.Size = new Size(160, 35);
            btnAddTransaction.TabIndex = 0;
            btnAddTransaction.Text = "+ Add Transaction";
            btnAddTransaction.UseVisualStyleBackColor = false;
            btnAddTransaction.Click += btnAddTransaction_Click;
            // 
            // btnManageCategories
            // 
            btnManageCategories.BackColor = Color.FromArgb(52, 73, 94);
            btnManageCategories.Cursor = Cursors.Hand;
            btnManageCategories.FlatAppearance.BorderSize = 0;
            btnManageCategories.FlatStyle = FlatStyle.Flat;
            btnManageCategories.Font = new Font("Segoe UI", 9F);
            btnManageCategories.ForeColor = Color.White;
            btnManageCategories.Location = new Point(311, 0);
            btnManageCategories.Name = "btnManageCategories";
            btnManageCategories.Size = new Size(170, 35);
            btnManageCategories.TabIndex = 1;
            btnManageCategories.Text = "Manage Categories";
            btnManageCategories.UseVisualStyleBackColor = false;
            btnManageCategories.Click += btnManageCategories_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.FromArgb(127, 140, 141);
            btnRefresh.Cursor = Cursors.Hand;
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.Font = new Font("Segoe UI", 9F);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(481, 0);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(116, 35);
            btnRefresh.TabIndex = 2;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnPredictions
            // 
            btnPredictions.BackColor = Color.FromArgb(41, 128, 185);
            btnPredictions.Cursor = Cursors.Hand;
            btnPredictions.FlatAppearance.BorderSize = 0;
            btnPredictions.FlatStyle = FlatStyle.Flat;
            btnPredictions.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnPredictions.ForeColor = Color.White;
            btnPredictions.Location = new Point(10, 60);
            btnPredictions.Name = "btnPredictions";
            btnPredictions.Size = new Size(180, 35);
            btnPredictions.TabIndex = 2;
            btnPredictions.Text = "▶ Run Predictions";
            btnPredictions.UseVisualStyleBackColor = false;
            btnPredictions.Click += btnPredictions_Click;
            // 
            // lblPredictionsTitle
            // 
            lblPredictionsTitle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblPredictionsTitle.ForeColor = Color.FromArgb(44, 62, 80);
            lblPredictionsTitle.Location = new Point(10, 10);
            lblPredictionsTitle.Name = "lblPredictionsTitle";
            lblPredictionsTitle.Size = new Size(340, 24);
            lblPredictionsTitle.TabIndex = 3;
            lblPredictionsTitle.Text = "Next-Month Spending Forecast";
            // 
            // lstPredictions
            // 
            lstPredictions.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstPredictions.BackColor = Color.FromArgb(245, 248, 252);
            lstPredictions.BorderStyle = BorderStyle.None;
            lstPredictions.Font = new Font("Consolas", 9F);
            lstPredictions.Location = new Point(10, 105);
            lstPredictions.Name = "lstPredictions";
            lstPredictions.SelectionMode = SelectionMode.None;
            lstPredictions.Size = new Size(340, 826);
            lstPredictions.TabIndex = 0;
            // 
            // lblPredictionsHint
            // 
            lblPredictionsHint.Font = new Font("Segoe UI", 8F);
            lblPredictionsHint.ForeColor = Color.Gray;
            lblPredictionsHint.Location = new Point(10, 36);
            lblPredictionsHint.Name = "lblPredictionsHint";
            lblPredictionsHint.Size = new Size(340, 18);
            lblPredictionsHint.TabIndex = 1;
            lblPredictionsHint.Text = "ML linear regression · last 6 months of data";
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1 });
            statusStrip1.Location = new Point(0, 598);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1000, 22);
            statusStrip1.TabIndex = 3;
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(39, 17);
            toolStripStatusLabel1.Text = "Ready";
            // 
            // pnlLeft
            // 
            pnlLeft.Controls.Add(dgvRecentTxns);
            pnlLeft.Controls.Add(pnlButtons);
            pnlLeft.Controls.Add(lblBalanceHint);
            pnlLeft.Controls.Add(lblBalance);
            pnlLeft.Controls.Add(lblBalanceCaption);
            pnlLeft.Dock = DockStyle.Left;
            pnlLeft.Location = new Point(0, 60);
            pnlLeft.Name = "pnlLeft";
            pnlLeft.Padding = new Padding(10);
            pnlLeft.Size = new Size(620, 538);
            pnlLeft.TabIndex = 1;
            // 
            // pnlButtons
            // 
            pnlButtons.Controls.Add(btnDeleteTransaction);
            pnlButtons.Controls.Add(btnAddTransaction);
            pnlButtons.Controls.Add(btnManageCategories);
            pnlButtons.Controls.Add(btnRefresh);
            pnlButtons.Location = new Point(10, 105);
            pnlButtons.Name = "pnlButtons";
            pnlButtons.Size = new Size(604, 40);
            pnlButtons.TabIndex = 1;
            // 
            // btnDeleteTransaction
            // 
            btnDeleteTransaction.BackColor = Color.IndianRed;
            btnDeleteTransaction.Cursor = Cursors.Hand;
            btnDeleteTransaction.FlatAppearance.BorderSize = 0;
            btnDeleteTransaction.FlatStyle = FlatStyle.Flat;
            btnDeleteTransaction.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDeleteTransaction.Location = new Point(155, 0);
            btnDeleteTransaction.Name = "btnDeleteTransaction";
            btnDeleteTransaction.Size = new Size(160, 35);
            btnDeleteTransaction.TabIndex = 0;
            btnDeleteTransaction.Text = "- Delete Transaction";
            btnDeleteTransaction.UseVisualStyleBackColor = false;
            btnDeleteTransaction.Click += btnDeleteTransaction_Click;
            // 
            // pnlRight
            // 
            pnlRight.BackColor = Color.FromArgb(245, 248, 252);
            pnlRight.Controls.Add(lstPredictions);
            pnlRight.Controls.Add(lblPredictionsHint);
            pnlRight.Controls.Add(btnPredictions);
            pnlRight.Controls.Add(lblPredictionsTitle);
            pnlRight.Dock = DockStyle.Fill;
            pnlRight.Location = new Point(620, 60);
            pnlRight.Name = "pnlRight";
            pnlRight.Padding = new Padding(10);
            pnlRight.Size = new Size(380, 538);
            pnlRight.TabIndex = 0;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(44, 62, 80);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(1000, 60);
            pnlHeader.TabIndex = 2;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1000, 620);
            Controls.Add(pnlRight);
            Controls.Add(pnlLeft);
            Controls.Add(pnlHeader);
            Controls.Add(statusStrip1);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(900, 560);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Finance Tracker";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvRecentTxns).EndInit();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            pnlLeft.ResumeLayout(false);
            pnlButtons.ResumeLayout(false);
            pnlRight.ResumeLayout(false);
            pnlHeader.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        // ── Control declarations ──────────────────────────────────
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblBalanceCaption;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblBalanceHint;
        private System.Windows.Forms.DataGridView dgvRecentTxns;
        private System.Windows.Forms.Button btnAddTransaction;
        private System.Windows.Forms.Button btnManageCategories;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnPredictions;
        private System.Windows.Forms.Label lblPredictionsTitle;
        private System.Windows.Forms.ListBox lstPredictions;
        private System.Windows.Forms.Label lblPredictionsHint;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Panel pnlButtons;
        private Button btnDeleteTransaction;
    }
}