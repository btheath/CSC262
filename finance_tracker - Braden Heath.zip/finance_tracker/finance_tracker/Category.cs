﻿using System;
using System.Drawing;  

namespace FinanceTracker.Classes
{
    // Represents a financial category, such as "Groceries" or "Salary".
    public class Category
    {
        // Unique identifier for the category, typically assigned by the database.
        public int CategoryId { get; set; }

        // Name of the category, e.g., "Groceries", "Utilities", "Salary".
        public string CategoryName { get; set; }

        // Type of the category, either "Expense" or "Income".
        public string CategoryType { get; set; }

        // Optional monthly budget limit for this category. For expenses, this can help track overspending.
        public decimal MonthlyBudgetLimit { get; set; }

        // Hexadecimal color code for UI representation, e.g., "#FF5733". This allows users to visually distinguish categories.
        public string HexColor { get; set; }

        
        // Default constructor with safe initial values.        
        public Category()
        {
            CategoryId = 0;
            CategoryName = string.Empty;
            CategoryType = "Expense";
            MonthlyBudgetLimit = 0m;
            HexColor = "#607D8B";  
        }

      
        // Converts the stored hex string to a System.Drawing.Color        
        // Falls back to LightGray if the string is invalid.        
        public Color GetColor()
        {
            try
            {
                return ColorTranslator.FromHtml(HexColor);
            }
            catch
            {
                return Color.LightGray;
            }
        }

        
        // Used in ComboBox / ListBox bindings so the category name
        // appears as is without extra text.        
        public override string ToString() => CategoryName;
    }
}
