﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using FinanceTracker.Classes;
using FinanceTracker.Database;

namespace FinanceTracker.Forms
{
    public partial class TransactionForm : Form
    {
        // The full list of categories loaded from the DB.
        // Stored as a field so we can look up CategoryId by ComboBox selection.
        private List<Category> _availableCategories;

     
       
        // Load event. Opens the form ready to add a brand new transaction.        
        public TransactionForm()
        {
            InitializeComponent();
        }

        private void TransactionForm_Load(object sender, EventArgs e)
        {
            this.Text = "Add New Transaction";
            lblFormTitle.Text = "➕ Add New Transaction";

            // Load the Type combo box with fixed options
            cboType.Items.Clear();
            cboType.Items.Add("Expense");
            cboType.Items.Add("Income");
            cboType.SelectedIndex = 0;   // default to Expense

            // Load categories from the database into the combo box
            LoadCategories();

            // Add a tooltip to the Amount field to clarify expected input format
            var toolTip = new ToolTip();
            toolTip.SetToolTip(txtAmount, "Enter a positive number, e.g. 42.50");
            toolTip.SetToolTip(cboCategory, "Select the category that best fits this transaction.");
        }

        
        // Fetches all Category objects from the DB and binds them to the combo box.
        // Each Category object is stored in the Items collection so we can retrieve CategoryId directly from the selection.        
        private void LoadCategories()
        {
            try
            {
                _availableCategories = DatabaseHelper.GetAllCategories();

                cboCategory.Items.Clear();
                foreach (Category cat in _availableCategories)
                    cboCategory.Items.Add(cat);   // Category.ToString() returns CategoryName

                // DisplayMember not needed because we overrode ToString() in Category class
                if (cboCategory.Items.Count > 0)
                    cboCategory.SelectedIndex = 0;
                else
                    ShowValidationMessage("No categories found. Please add a category first.", Color.Orange);
            }
            catch (Exception ex)
            {
                ShowValidationMessage($"Could not load categories: {ex.Message}", Color.Red);
            }
        }

        // Validates all required fields. Returns true if everything is valid; false otherwise.
        // Shows a descriptive message for the first validation failure.        
        private bool ValidateInputs()
        {
            HideValidationMessage();  // clear previous errors

            // Category required
            if (cboCategory.SelectedItem == null)
            {
                ShowValidationMessage("Please select a category.", Color.Red);
                cboCategory.Focus();
                return false;
            }

            // Amount required and must be a positive number 
            string rawAmount = txtAmount.Text.Trim();
            if (string.IsNullOrEmpty(rawAmount))
            {
                ShowValidationMessage("Please enter an amount.", Color.Red);
                txtAmount.Focus();
                return false;
            }
            // Try parsing the amount to a decimal. It must be a positive number.
            if (!decimal.TryParse(rawAmount, out decimal parsedAmount) || parsedAmount <= 0)
            {
                ShowValidationMessage("Amount must be a positive number (e.g. 24.99).", Color.Red);
                txtAmount.Focus();
                return false;
            }
            // enforce a reasonable upper limit to catch accidental extra zeros (e.g. 1000000000 instead of 10000000)            
            if (parsedAmount > 999_999_999)
            {
                ShowValidationMessage("Amount seems too large. Please double-check.", Color.Orange);
                txtAmount.Focus();
                return false;
            }

            // Date cannot be in the far future 
            if (dtpDate.Value.Date > DateTime.Today.AddYears(1))
            {
                ShowValidationMessage("Transaction date cannot be more than a year in the future.", Color.Orange);
                dtpDate.Focus();
                return false;
            }

            return true;   // all validations passed
        }        

        // Displays a validation message panel at the top of the form.
        private void ShowValidationMessage(string message, Color backgroundColor)
        {
            lblValidationMsg.Text = message;
            pnlValidation.BackColor = backgroundColor;
            pnlValidation.Visible = true;
        }

        // Hides the validation message panel.
        private void HideValidationMessage()
        {
            pnlValidation.Visible = false;
        }

        // Builds a Transaction object from the form inputs and either
        // inserts it (add mode) or updates it (edit mode) via DatabaseHelper.        
        private void SaveTransaction()
        {
            if (!ValidateInputs()) return;  // stop if validation fails

            // Get the selected Category object (we stored the full object in Items)
            var selectedCategory = (Category)cboCategory.SelectedItem;

            // Build a Transaction object from the current form state.
            // Multiple Transaction objects are created across the app — here is one instance.
            var txn = new Transaction
            {
                CategoryId = selectedCategory.CategoryId,
                Amount = decimal.Parse(txtAmount.Text.Trim()),
                TransactionType = cboType.SelectedItem.ToString(),
                Description = txtDescription.Text.Trim(),
                TransactionDate = dtpDate.Value.Date
            };
            // Insert the transaction into the database. DatabaseHelper will set the TransactionId and CreatedAt fields.
            try
            {
                DatabaseHelper.InsertTransaction(txn);

                MessageBox.Show(
                    "Transaction saved successfully!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                ShowValidationMessage($"Save failed: {ex.Message}", Color.Red);
            }
        }
        // Save button click handler. Validates inputs and saves the transaction if everything is valid.
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveTransaction();
        }
        // Cancel button click handler. Closes the form without saving any changes.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // No changes should be saved — just close
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        
        // When the user selects a category, automatically switch the Type combo to match the category's default type for convenience.
        // The user can still override the auto-selection.        
        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboCategory.SelectedItem is Category selectedCat)
                cboCategory.SelectedItem = selectedCat;  // no-op; hook for future type auto-fill
        }

        // Restricts the amount text box to numeric input with at most one decimal point.
        // KeyPress fires before the character is inserted, so we can block bad input early.        
        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow control characters (Backspace, Delete, etc.)
            if (char.IsControl(e.KeyChar)) return;

            // Allow digits
            if (char.IsDigit(e.KeyChar)) return;

            // Allow exactly one decimal point
            if (e.KeyChar == '.' && !txtAmount.Text.Contains('.')) return;

            // Block everything else
            e.Handled = true;
        }
    }
}
