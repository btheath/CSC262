﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using FinanceTracker.Classes;
using FinanceTracker.Database;

namespace FinanceTracker.Forms
{
    public partial class CategoryManagerForm : Form
    {
        // Master list of Category objects loaded from the database.
        // Multiple Category objects are created from each DB row.
        private List<Category> _categories;

        // Tracks which category is being edited so we know
        // whether btnSaveEdit should INSERT or UPDATE.
        private Category _categoryBeingEdited;
                
        // Initializes the form and sets up initial state.
        public CategoryManagerForm()
        {
            InitializeComponent();
            _categories = new List<Category>();
            _categoryBeingEdited = null;
        }
        
        private void CategoryManagerForm_Load(object sender, EventArgs e)
        {
            this.Text = "Finance Tracker – Category Manager";

            // Set up the grid columns before binding data
            ConfigureCategoryGrid();

            // Hide the edit panel until the user clicks Add or a row
            pnlEdit.Visible = false;

            // Load and display categories from the database
            LoadCategories();

            // Populate the Type combo inside the edit panel
            cboEditType.Items.Clear();
            cboEditType.Items.Add("Expense");
            cboEditType.Items.Add("Income");
            cboEditType.SelectedIndex = 0;
        }        
        
        // Defines which columns appear in the category DataGridView
        // and how they are sized. Called once at form load.        
        private void ConfigureCategoryGrid()
        {
            dgvCategories.AutoGenerateColumns = false;
            dgvCategories.AllowUserToAddRows = false;
            dgvCategories.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCategories.RowHeadersVisible = false;
            dgvCategories.Columns.Clear();

            dgvCategories.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colId",
                HeaderText = "ID",
                DataPropertyName = "CategoryId",
                Width = 40,
                ReadOnly = true
            });

            dgvCategories.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colName",
                HeaderText = "Category Name",
                DataPropertyName = "CategoryName",
                Width = 160
            });

            dgvCategories.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colType",
                HeaderText = "Type",
                DataPropertyName = "CategoryType",
                Width = 75
            });

            dgvCategories.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colBudget",
                HeaderText = "Monthly Limit ($)",
                DataPropertyName = "MonthlyBudgetLimit",
                Width = 110,
                DefaultCellStyle = { Format = "F2", Alignment = DataGridViewContentAlignment.MiddleRight }
            });

            dgvCategories.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colColor",
                HeaderText = "Color",
                DataPropertyName = "HexColor",
                Width = 80
            });
        }
        
        // Retrieves all Category objects from the database and binds them to the DataGridView. Also adds a color swatch
        // to each row so the user can see the category color at a glance.        
        private void LoadCategories()
        {
            try
            {
                _categories = DatabaseHelper.GetAllCategories();

                // Rebind the grid
                dgvCategories.DataSource = null;
                dgvCategories.DataSource = _categories;

                // Color each row's background to match its category color
                ApplyCategoryRowColors();

                lblStatus.Text = $"{_categories.Count} categories loaded.";
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"Load error: {ex.Message}";
                lblStatus.ForeColor = Color.Red;
            }
        }

        
        // Iterates the grid rows and tints each row's background
        // with the category's defined color so it's instantly recognisable.       
        private void ApplyCategoryRowColors()
        {
            foreach (DataGridViewRow row in dgvCategories.Rows)
            {
                if (row.DataBoundItem is Category cat)
                {
                    // Use a lighter tint so text remains readable
                    Color baseColor = cat.GetColor();
                    // Blend the color with white at 80% white for readability
                    int r = (int)(baseColor.R * 0.25 + 255 * 0.75);
                    int g = (int)(baseColor.G * 0.25 + 255 * 0.75);
                    int b = (int)(baseColor.B * 0.25 + 255 * 0.75);
                    row.DefaultCellStyle.BackColor = Color.FromArgb(r, g, b);
                }
            }
        }

        
        // Shows the edit panel and pre-fills it with the given category's data.
        // Passing null opens the panel in "add new" mode with blank fields.        
        private void ShowEditPanel(Category categoryToEdit)
        {
            _categoryBeingEdited = categoryToEdit;

            if (categoryToEdit == null)
            {
                // Add new mode: clear all fields for the user to enter new data
                txtEditName.Text = string.Empty;
                cboEditType.SelectedIndex = 0;    // default to Expense
                txtEditBudget.Text = "0";
                txtEditColor.Text = "#607D8B";
                UpdateColorPreview("#607D8B");
            }
            else
            {
                // Load the selected category's data into the edit fields
                txtEditName.Text = categoryToEdit.CategoryName;
                cboEditType.SelectedItem = categoryToEdit.CategoryType;
                txtEditBudget.Text = categoryToEdit.MonthlyBudgetLimit.ToString("F2");
                txtEditColor.Text = categoryToEdit.HexColor;
                UpdateColorPreview(categoryToEdit.HexColor);
            }

            pnlEdit.Visible = true;
            txtEditName.Focus();
        }

        
        // Updates the small color-preview panel with the hex string
        // so the user gets immediate visual feedback as they type.        
        private void UpdateColorPreview(string hexColor)
        {
            try
            {
                pnlColorPreview.BackColor = ColorTranslator.FromHtml(hexColor);
            }
            catch
            {
                pnlColorPreview.BackColor = Color.LightGray;  // fallback on invalid hex
            }
        }      
                
        // Validates the edit panel fields.
        // Returns true if all inputs are valid.        
        private bool ValidateEditInputs()
        {
            string name = txtEditName.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Category name is required.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEditName.Focus();
                return false;
            }

            if (name.Length > 50)
            {
                MessageBox.Show("Category name must be 50 characters or fewer.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEditName.Focus();
                return false;
            }

            // Budget limit must be a non-negative number
            if (!decimal.TryParse(txtEditBudget.Text.Trim(), out decimal budget) || budget < 0)
            {
                MessageBox.Show("Monthly budget limit must be 0 or a positive number.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEditBudget.Focus();
                return false;
            }

            // Color must be a valid hex code
            try
            {
                ColorTranslator.FromHtml(txtEditColor.Text.Trim());
            }
            catch
            {
                MessageBox.Show("Color must be a valid hex code, e.g. #FF5733", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEditColor.Focus();
                return false;
            }

            return true;
        }

        // Event handlers for the buttons and grid interactions. Each handler performs
        private void btnAddNew_Click(object sender, EventArgs e)
        {
            ShowEditPanel(null);   // null = add new mode
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Guard: make sure a row is selected
            if (dgvCategories.CurrentRow?.DataBoundItem is not Category selectedCat)
            {
                MessageBox.Show("Please select a category to delete.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Confirm before deleting — good UX practice
            DialogResult confirm = MessageBox.Show(
                $"Delete category '{selectedCat.CategoryName}'?\n\n" +
                "This will fail if any transactions still use this category.",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            try
            {
                DatabaseHelper.DeleteCategory(selectedCat.CategoryId);
                lblStatus.Text = $"Deleted '{selectedCat.CategoryName}'.";
                lblStatus.ForeColor = Color.DarkGreen;
                LoadCategories();
            }
            catch (Exception ex)
            {
                // Likely a foreign-key constraint violation
                MessageBox.Show(
                    $"Could not delete category.\n\n{ex.Message}\n\n" +
                    "Tip: Delete or reassign all transactions in this category first.",
                    "Delete Failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnSaveEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateEditInputs()) return;

            // Build a Category object from the edit panel's current values.
            // This is another instance of the Category class being created.
            var cat = new Category
            {
                CategoryId = _categoryBeingEdited?.CategoryId ?? 0,
                CategoryName = txtEditName.Text.Trim(),
                CategoryType = cboEditType.SelectedItem.ToString(),
                MonthlyBudgetLimit = decimal.Parse(txtEditBudget.Text.Trim()),
                HexColor = txtEditColor.Text.Trim()
            };

            try
            {
                bool isNew = _categoryBeingEdited == null;

                if (isNew)
                    DatabaseHelper.InsertCategory(cat);
                else
                    DatabaseHelper.UpdateCategory(cat);

                lblStatus.Text = isNew ? "Category added." : "Category updated.";
                lblStatus.ForeColor = Color.DarkGreen;

                pnlEdit.Visible = false;
                _categoryBeingEdited = null;

                // Reload the grid to reflect the change
                LoadCategories();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelEdit_Click(object sender, EventArgs e)
        {
            pnlEdit.Visible = false;
            _categoryBeingEdited = null;
            lblStatus.Text = "Edit cancelled.";
            lblStatus.ForeColor = Color.Gray;
        }        
        // When the user clicks a grid row, automatically load that
        // category into the edit panel so they can modify it easily.        
        private void dgvCategories_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;   // ignore header clicks

            if (dgvCategories.Rows[e.RowIndex].DataBoundItem is Category selectedCat)
                ShowEditPanel(selectedCat);
        }                
        // Opens the system ColorDialog so the user can pick a color
        // graphically rather than typing a hex code manually.        
        private void btnPickColor_Click(object sender, EventArgs e)
        {
            using (var colorDialog = new ColorDialog())
            {
                // Pre-select the currently entered color if it's valid
                try { colorDialog.Color = ColorTranslator.FromHtml(txtEditColor.Text.Trim()); }
                catch { colorDialog.Color = Color.LightBlue; }

                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    // Convert back to hex string for storage
                    txtEditColor.Text = ColorTranslator.ToHtml(colorDialog.Color);
                    UpdateColorPreview(txtEditColor.Text);
                }
            }
        }

        
        // Live-previews the color as the user types in the hex field.        
        private void txtEditColor_TextChanged(object sender, EventArgs e)
        {
            UpdateColorPreview(txtEditColor.Text.Trim());
        }
    }
}
