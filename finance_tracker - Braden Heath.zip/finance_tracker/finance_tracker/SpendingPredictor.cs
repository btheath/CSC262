﻿// ============================================================
// SpendingPredictor.cs
// Provides basic Machine Learning functionality: a simple
// linear regression that predicts next month's spending per
// category based on the last N months of historical data.
//
// no external library is required. Linear regression is computed manually
// using the least-squares formula:
//   slope     = (n*Σxy - Σx*Σy) / (n*Σx² - (Σx)²)
//   intercept = (Σy - slope*Σx) / n
// where x = month index (1,2,3…) and y = spending amount.
// ============================================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace FinanceTracker.Classes
{
    /// <summary>
    /// Wraps a per-category spending prediction result.
    /// </summary>
    public class PredictionResult
    {
        /// <summary>Name of the category being predicted.</summary>
        public string CategoryName { get; set; }

        /// <summary>ML-predicted spending amount for next month.</summary>
        public decimal PredictedAmount { get; set; }

        /// <summary>
        /// The trend direction derived from the regression slope.
        /// Helps the user understand the forecast at a glance.
        /// </summary>
        public string Trend { get; set; }  // "Increasing", "Decreasing", or "Stable"

        /// <summary>
        /// Confidence level as a percentage (0-100).
        /// Derived from the R² coefficient of determination.
        /// </summary>
        public double ConfidencePercent { get; set; }
    }

    /// <summary>
    /// Performs simple linear-regression–based spending forecasts.
    /// Create one instance, feed it monthly spending data, and call
    /// PredictNextMonth() to get predictions for each category.
    /// </summary>
    public class SpendingPredictor
    {
        // ── Internal data structure ──────────────────────────────

        // Key   = category name
        // Value = ordered list of monthly spending totals (oldest first)
        private readonly Dictionary<string, List<decimal>> _monthlySpendingHistory;

        // ── Constructor ─────────────────────────────────────────

        /// <summary>
        /// Initialises the predictor with an empty history dictionary.
        /// Call LoadHistory() before making predictions.
        /// </summary>
        public SpendingPredictor()
        {
            _monthlySpendingHistory = new Dictionary<string, List<decimal>>();
        }

        // ── Public API ───────────────────────────────────────────

        /// <summary>
        /// Loads historical monthly spending totals into the predictor.
        /// </summary>
        /// <param name="categoryName">Name of the spending category.</param>
        /// <param name="monthlyTotals">
        /// List of monthly totals in chronological order.
        /// Must have at least 2 entries for regression to be meaningful.
        /// </param>
        public void LoadHistory(string categoryName, List<decimal> monthlyTotals)
        {
            if (string.IsNullOrWhiteSpace(categoryName) || monthlyTotals == null)
                return;

            // Store or overwrite the history for this category
            _monthlySpendingHistory[categoryName] = monthlyTotals;
        }

        /// <summary>
        /// Runs linear regression for every category that has been loaded
        /// and returns a prediction for the next calendar month.
        /// Categories with fewer than 2 data points are skipped.
        /// </summary>
        /// <returns>List of PredictionResult objects, one per category.</returns>
        public List<PredictionResult> PredictNextMonth()
        {
            var results = new List<PredictionResult>();

            foreach (var kvp in _monthlySpendingHistory)
            {
                string categoryName = kvp.Key;
                List<decimal> history = kvp.Value;

                // Need at least 2 months to fit a line
                if (history.Count < 2)
                    continue;

                // ── Step 1: build x and y arrays ────────────────
                // x = month index (1-based), y = spending amount
                int n = history.Count;
                double[] x = new double[n];
                double[] y = new double[n];

                for (int i = 0; i < n; i++)
                {
                    x[i] = i + 1;                        // 1, 2, 3, …
                    y[i] = (double)history[i];           // cast decimal → double
                }

                // ── Step 2: compute sums for least-squares ───────
                double sumX = x.Sum();
                double sumY = y.Sum();
                double sumXY = x.Zip(y, (xi, yi) => xi * yi).Sum();
                double sumX2 = x.Select(xi => xi * xi).Sum();

                // ── Step 3: slope and intercept ──────────────────
                double denominator = (n * sumX2) - (sumX * sumX);

                // Guard against division by zero (all x values identical)
                if (Math.Abs(denominator) < 1e-10)
                    continue;

                double slope = ((n * sumXY) - (sumX * sumY)) / denominator;
                double intercept = (sumY - (slope * sumX)) / n;

                // ── Step 4: predict the NEXT month (index = n+1) ─
                double predictedRaw = intercept + slope * (n + 1);
                decimal predictedAmount = (decimal)Math.Max(0, predictedRaw); // spending can't be negative

                // ── Step 5: determine trend label ────────────────
                string trend;
                if (slope > 2.0) trend = "Increasing";
                else if (slope < -2.0) trend = "Decreasing";
                else trend = "Stable";

                // ── Step 6: R² (coefficient of determination) ────
                // Measures how well the line fits the data (0 = poor, 1 = perfect)
                double yMean = sumY / n;
                double ssTot = y.Select(yi => Math.Pow(yi - yMean, 2)).Sum();
                double ssRes = x.Zip(y, (xi, yi) =>
                                  Math.Pow(yi - (intercept + slope * xi), 2)).Sum();
                double rSquared = (ssTot < 1e-10) ? 1.0 : 1.0 - (ssRes / ssTot);
                double confidence = Math.Max(0, Math.Min(100, rSquared * 100));

                // ── Step 7: package the result ────────────────────
                results.Add(new PredictionResult
                {
                    CategoryName = categoryName,
                    PredictedAmount = predictedAmount,
                    Trend = trend,
                    ConfidencePercent = Math.Round(confidence, 1)
                });
            }

            // Sort by predicted amount descending so highest risks appear first
            results.Sort((a, b) => b.PredictedAmount.CompareTo(a.PredictedAmount));
            return results;
        }

        /// <summary>
        /// Removes all previously loaded history so the predictor can be
        /// reused with fresh data without creating a new instance.
        /// </summary>
        public void ClearHistory()
        {
            _monthlySpendingHistory.Clear();
        }
    }
}
