﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace VideoGameProgram
{
    // Interface to ensure that any class that implements it has a Display method
    public interface IDisplayable {
        // Display method that returns a string representation of the object
        string Display();

        // Display method that takes an integer parameter to specify how many attributes to display
        string Display(int attributeCount);
    
    }
    public class Character : IDisplayable
    {
        // private local variables for the Character class
        private string name;
        private int health;
        private List<string> inventory;
        private int attack;
        private int speed;
        private int defense;

        // public properties
        // Public property for the name, ensuring that it cannot be set to null or whitespace
        public string Name
        {
            get => name;
            set => name = string.IsNullOrWhiteSpace(value) ? "Unknown" : value.Trim();
        }
        // Public property for health, ensuring that it cannot be set to a negative value
        public int Health
        {
            get => health;
            set => health = value >= 0 ? value : 0;
        }
        // Public property for the inventory, which is a list of strings representing the items the character has
        public List<string> Inventory
        {
            get { return inventory; }
            set { inventory = value; }
        }

        // Ensure that attack value cannot be negative
        public int Attack
        {
            get => attack;
            set => attack = value >= 0 ? value : 0;
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }
        // Virtual property to allow subclasses to specify their character type
        public virtual string CharacterType => "Character";

        // building constructor for the Character class

        public Character(string new_name, int health, List<string> inventory, int attack, int speed, int defense)
        {
            Name = new_name;
            Health = health;
            Inventory = inventory;
            Attack = attack;
            Speed = speed;
            Defense = defense;
        }
        

        public Character(string new_name, int health, int attack, int speed, int defense)
        {
            Name = new_name;
            Health = health;
            Attack = attack;
            Speed = speed;
            Defense = defense;
        }

        public string Battle(bool hitLanded, int damage)
        {
            // If the hit landed, calculate the damage and update health
            if (hitLanded)
            {
                Health = Health - damage;

            }

            return $"Health is now {Health}";

        }

        // Method to display the character's information
        public virtual string Display()
        {
            // Create a string to represent the inventory, or indicate that there is no inventory
            string inventoryText = Inventory.Count > 0 ? string.Join(", ", Inventory) : "No inventory";
            // Return a string with the character's name, health, attack, speed, and defense
            return $"Character: {Name} has {Health} health with {Attack} attack, {Speed} speed, and {Defense} defense.";


        }
        public virtual string Display(int attributeCount)
        {
            // Create a list of the character's attributes as strings
            var attributes = new List<string>
            {
                $"Name: {Name}",
                $"Health: {Health}",
                $"Attack: {Attack}",
                $"Speed: {Speed}",
                $"Defense: {Defense}"
            };
            // Return only the specified number of attributes
            return string.Join(", ", attributes.Take(attributeCount));
        }

        public class Warrior : Character {
            // Additional properties specific to the Warrior class
            private int rageCharges;
            private double rageMultiplier;
            private int maxRageCharges;

            // Public properties for the Warrior class

            // Public property for the rage charges, which represents how many times the warrior can use a rage attack
            public int RageCharges 
             {
                    get => rageCharges;
                    set => rageCharges = Math.Clamp(value, 0, maxRageCharges);
             }

            // Public property for the rage multiplier, which increases the attack power when using a rage attack
            // Ensure that the rage multiplier cannot be set to less than 1.0, as it should always increase attack power
            public double RageMultiplier
            {
                    get => rageMultiplier;
                    set => rageMultiplier = value >= 1.0 ? value : 1.0;
            }

            // Public property for the maximum number of rage charges, ensuring it cannot be set to less than 1
            public int MaxRageCharges
            {
                get => maxRageCharges;
                set => maxRageCharges = value >= 1 ? value : 1;
            }

            // Constructor for the Warrior class, which takes all the parameters needed for the base Character class as well as the additional properties for the Warrior
            public Warrior(string new_name, int health, List<string> inventory, int attack, int speed, int defense, int rageCharges = 3, double rageMultiplier = 1.5) : base(new_name, health, inventory, attack, speed, defense)
            {
                MaxRageCharges = rageCharges;
                RageCharges = rageCharges;
                RageMultiplier = rageMultiplier;
            }

            // Override the Display method to include rage charges and multiplier when displaying the character's information
            public override string Display()
            {
                return base.Display() + $" Rage Charges: {RageCharges}, Rage Multiplier: {RageMultiplier}";
            }
            // Override the Display method to include rage charges and multiplier when displaying the character's information
            public override string Display(int attributeCount)
            {
                if (attributeCount > 5)
                {
                    return base.Display(attributeCount) + $", Rage Charges: {RageCharges}, Rage Multiplier: {RageMultiplier}";
                }
                else
                {
                    return base.Display(attributeCount);
                }
            }



        }

        // Mage class that inherits from Character and implements the IDisplayable interface
        public class Mage : Character
        {
            // Additional properties specific to the Mage class
            private int mana;
            private int maxMana;
            private double spellPower;
            // Public properties for the Mage class

            // Public property for mana, which represents the current mana points the mage has available for casting spells
            public int Mana
            {
                get => mana;
                // Ensure that mana cannot be set to a value less than 0 or greater than maxMana
                set => mana = Math.Clamp(value, 0, MaxMana);
            }

            // Public property for max mana, which represents the maximum mana points the mage can have
            public int MaxMana
            {
                get => maxMana;
                set => maxMana = value >= 1 ? value : 1;
            }

            //  Public property for spell power bonus, which increases the damage of the mage's spells
            // Ensure that the spell power bonus cannot be set to less than 1.0, as it should always increase spell damage
            public double SpellPowerBonus
            {
                get => spellPower;
                set => spellPower = value >= 1.0 ? value : 1.0;
            }

            // Constructor for the Mage class, which takes all the parameters needed for the base Character class as well as the additional properties for the Mage
            public Mage(string new_name, int health, List<string> inventory, int attack, int speed, int defense, int maxMana = 100, double spellPower = 1.5) : base(new_name, health, inventory, attack, speed, defense)
            {
                MaxMana = maxMana;
                Mana = maxMana;
                SpellPowerBonus = spellPower;

            }

     

            // Override the Display method to include mana and spell power bonus when displaying the character's information
            public override string Display()
            {
                return base.Display() + $" Mana: {Mana}/{MaxMana}, Spell Power Bonus: {SpellPowerBonus}";
            }

            // Override the Display method to include mana and spell power bonus when displaying the character's information
            public override string Display(int attributeCount)
            {
                return base.Display(attributeCount);
            }

        }

        }
    }
