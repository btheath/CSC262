using static VideoGameProgram.Character;

namespace VideoGameProgram
{
    public partial class frmCharacterView : Form
    {
        public frmCharacterView()
        {
            InitializeComponent();
            UpdateSubclassPanel();
        }

        // Method to show or hide the subclass-specific controls based on the selected character type
        private void UpdateSubclassPanel()
        {
            // Ensure the ComboBox is not null before trying to access its properties
            if (cmbCharacterType == null) return;

            // Determine which character type is selected
            bool isWarrior = cmbCharacterType.SelectedItem?.ToString() == "Warrior";
            bool isMage = cmbCharacterType.SelectedItem?.ToString() == "Mage";

            // Warrior controls
            // Show or hide the warrior-specific controls based on the selection
            lblRageCharges.Visible = isWarrior;
            numRageCharges.Visible = isWarrior;
            lblRageMultiplier.Visible = isWarrior;
            numRageMultiplier.Visible = isWarrior;

            // Mage controls
            // Show or hide the mage-specific controls based on the selection
            lblMaxMana.Visible = isMage;
            numMaxMana.Visible = isMage;
            lblSpellPower.Visible = isMage;
            numSpellPower.Visible = isMage;
        }

        // create a list to hold the characters we create
        private List<Character> existingCharacters = new List<Character>();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            // validate that the user has entered a name for the character before creating it
            if (string.IsNullOrWhiteSpace(textName.Text))
            {
                lblCharacterInfo.Text = "Please enter a character name.";
                return;
            }

            string charName = textName.Text;
            int health = (int)numHealth.Value;

            // take the inventory string and convert to an array and then a list
            List<string> inventory = textInventory.Text.Split(',').ToList();

            int attack = (int)numAttack.Value;
            int speed = (int)numSpeed.Value;
            int defense = (int)numDefense.Value;



            Character newCharacter;

            // Build the correct subclass based on user selection
            switch (cmbCharacterType.SelectedItem?.ToString())
            {
                // If the user selects "Warrior", create a new Warrior object with the appropriate attributes
                case "Warrior":
                    newCharacter = new Warrior(
                        charName, health, inventory, attack, speed, defense,
                        rageCharges: (int)numRageCharges.Value,
                        rageMultiplier: (double)numRageMultiplier.Value);
                    break;
                // If the user selects "Mage", create a new Mage object with the appropriate attributes
                case "Mage":
                    newCharacter = new Mage(
                        charName, health, inventory, attack, speed, defense,
                        maxMana: (int)numMaxMana.Value,
                        spellPower: (double)numSpellPower.Value);
                    break;
                // If the user selects "Character" or if no valid selection is made, create a base Character object
                default: // "Character" (base)
                    newCharacter = new Character(charName, health, inventory,
                                                 attack, speed, defense);
                    break;
            }
            // Show all attributes on the info label
            lblCharacterInfo.Text = newCharacter.Display();

            // Add to master list and refresh the characters ListBox
            existingCharacters.Add(newCharacter);
            LoadCharacters();
        }

        //create a method to load the existing characters into the character listbox
        private void LoadCharacters()
        {
            lbCharacters.Items.Clear();
            // loop through the list of existing characters and add their names to the listbox
            foreach (Character character in existingCharacters)
            {
                // use the Display method to show the character's name and health in the listbox
                lbCharacters.Items.Add($"{character.CharacterType}: {character.Name}");
            }
        }

        private void lbCharacters_SelectedIndexChanged(object sender, EventArgs e)
        {
            //remove any items currently in the inventory list
            lbInventory.Items.Clear();
            // get the selected character from the listbox using the selected index and display their info in the label
            Character selCharacter = existingCharacters[lbCharacters.SelectedIndex];

            lblCharacterInfo.Text = selCharacter.Display();

            // let user know if the character has no inventory
            if (selCharacter.Inventory.Count == 0)
            {
                lblCharacterInfo.Text = $"{selCharacter.Name} has no inventory.";
            }
            else
            {
                foreach (string item in selCharacter.Inventory)
                {
                    lbInventory.Items.Add(item.Trim());
                }
            }
        }

        // When the user changes the character type selection, update the subclass panel to show the appropriate controls
        private void cmbCharacterType_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSubclassPanel();
        }

        
    }
}
